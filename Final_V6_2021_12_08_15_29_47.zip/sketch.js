let serial;
let pins = [256, 256];

let pX, pY;


let latestData = "waiting for data";

var color_slider;




function setup() {
  createCanvas(600, 600);
  
  colorMode(HSB);
    color_slider = createSlider(0, 255, 0, 2);
    color_slider.position(20, 600);
    color_slider.style('200px', '200px');
  
  textSize(15);
  
  pX = width/2;
  pY = height/2;

  frameRate(70);

  
  serial = new p5.SerialPort(); //Serial port connect
  
  serial.list();
  serial.open('COM3');
  serial.on('connected', serverConnected);
  serial.on('list', gotList);
  serial.on('data', gotData);
  serial.on('error', gotError);
  serial.on('open', gotOpen);
  serial.on('close', gotClose);
  

}

function serverConnected() {   //making sure
  print("Connected to Server");
}

function gotList(thelist) {
  print("List of Serial Ports: ");
    
    for (let i = 0; i < thelist.length; i++) {
      print(i + "" + thelist[i]);
      
    }
  
}

function gotOpen() {  //making sure port is connected
  print("Serial Port is Open"); 
  serial.clear();
  serial.write('A');
}

function gotClose() {
  print("Serial Port is Closed");
  latestData = "Serial Port is Closed";
}

function gotError(theerror) {
  print(theerror);
}

function gotData() {
  let currentString = serial.readLine();
  trim(currentString);
  if(!currentString) return;
  pins = split(currentString, ',');
  console.log(pins);
  latestData = currentString;
  serial.write('A');
}



function draw() {
  // background(220);
  
  col = color_slider.value();
  
  textAlign(100);
  brushcolor();
  
  noStroke();
  strokeWeight(3);
  fill (col, 60, 200);
  
  
  ellipse(pX, pY, 25);
  
  
  pX = pins[0];
  pY = pins[1];
  
  console.log (pX);
  

}

function brushcolor(){
  fill(0);
  
  text('Brush Color', 20, 595);
}